# Entrega 3 - Proyecto de IIC2513 - Grupo 112 frontend

Crear archivo `.env` y colocar:

```bash
VITE_BACKEND_URL=some_url
```

## Levantar la aplicación en Render
Crearse una cuenta en Render y hacer tal .. Ingresar las variables env

La app se encuentra actualmente disponible en: (no está deployada aún)

## Correr el proyecto en locao
🧬 Para correr el proyecto, deberás clonar el repositorio, y en la carpeta padre ejecutar el comando de consola:

```bash
yarn
```

🚀 Finalmente, para ejecutar el servidor en local (modo development) debes correr el comando:

```bash
yarn dev
```