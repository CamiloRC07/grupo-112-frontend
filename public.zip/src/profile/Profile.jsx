function Profile() {
    return (
        <>
        <h1>Perfil de usuario</h1>
        <p>No implementado</p>
        </>
    )
}

export default Profile