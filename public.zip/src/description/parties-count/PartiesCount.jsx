import "./PartiesCount.css"

function PartiesCount() {
    return (
        <div className="parties-count">
                {/* Cero hardcodeado */}
                <p>¡0 partidas han sido creadas!</p>
        </div>
    )
}

export default PartiesCount