import "./Footer.css"

function Footer() {
    return (
        <footer>
            Made with 💜 by <a href="">Eduardo Contreras</a> & <a href="">Camilo Romero</a>.
        </footer>
        // TODO: links a usuario de github
    )
}

export default Footer